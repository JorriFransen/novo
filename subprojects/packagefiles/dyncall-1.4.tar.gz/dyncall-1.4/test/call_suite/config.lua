-- user config for rand-sig.lua:
minargs  = 0
maxargs  = 64
ncases   = 400
types    = "BcsijlCSIJLpfd"
seed     = 2342

