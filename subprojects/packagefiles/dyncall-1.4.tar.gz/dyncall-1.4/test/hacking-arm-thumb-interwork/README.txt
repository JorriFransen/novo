darwin:

  armv6:  addresses are even
      
    arm addresses are even
    thumb addresses are odd

  armv7:  addresses are odd -mthumb-interwork and -mno-thumb-interwork no effect
